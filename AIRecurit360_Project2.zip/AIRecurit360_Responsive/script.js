const menuButton = document.querySelector(".menu-toggle");
const navigation = document.querySelector(".main-nav");
const toast = document.querySelector(".toast");
menuButton?.addEventListener("click", () => {
  const isOpen = navigation.classList.toggle("open");
  menuButton.setAttribute("aria-expanded", String(isOpen));
  menuButton.setAttribute("aria-label", isOpen ? "Close navigation" : "Open navigation");
});
document.querySelectorAll('a[href^="#"]').forEach((link) => {
  link.addEventListener("click", (event) => {
    const targetId = link.getAttribute("href");
    if (targetId === "#") {
      event.preventDefault();
      showMessage("AIRecruit360 home");
      return;
    }
    const target = document.querySelector(targetId);
    if (!target) {
      event.preventDefault();
      showMessage(`${link.textContent.trim()} — demo placeholder`);
    }
    navigation?.classList.remove("open");
    menuButton?.setAttribute("aria-expanded", "false");
  });
});
document.querySelector(".language")?.addEventListener("click", () => {
  showMessage("Language selector demo");
});
function showMessage(message) {
  if (!toast) return;
  toast.textContent = message;
  toast.classList.add("show");
  window.clearTimeout(showMessage.timer);
  showMessage.timer = window.setTimeout(() => toast.classList.remove("show"), 2200);
}
